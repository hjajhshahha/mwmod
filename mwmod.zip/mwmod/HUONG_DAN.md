# Menu mod MobaWar (offline) - hướng dẫn

Chưa chạy thử trên máy thật. Mã đã qua kiểm tra cú pháp (C++ bằng g++, Java bằng javac với stub Android), nhưng chưa build bằng NDK và chưa chạy trong game.

## 1. Cấu trúc
- `app/src/main/cpp/mwmenu.cpp`: phần native. Tra class/field theo TÊN qua IL2CPP API (không dùng offset cố định), quét bộ nhớ tìm tướng, sửa chỉ số, tìm và cộng tài nguyên, lưu cài đặt.
- `app/src/main/java/com/mw/Menu.java`: giao diện (panel kéo thả, bong bóng, tab Chỉ số / Tài nguyên).
- `app/src/main/java/com/mw/MenuProvider.java`: tự khởi động cùng app, KHÔNG cần sửa smali.
- `IL2CPP_DUMP.txt`: tên class/field/hàm đã trích từ global-metadata.dat.

## 2. Build
Mở thư mục này bằng Android Studio (hoặc AndroidIDE trên điện thoại), chọn Build > Build APK. Cần NDK và CMake (Android Studio sẽ tự hỏi cài).
Sau khi build, mở `app-debug.apk` bằng MT Manager và lấy:
1. `classes.dex` (đổi tên thành `classes4.dex`)
2. `lib/arm64-v8a/libmwmenu.so`

## 3. Gắn vào game
1. Mở `com.haibop.mobawar.apk`, thêm `classes4.dex` vào gốc APK.
2. Sửa `AndroidManifest.xml` của APK này: trong thẻ `<application>` thêm
   `<provider android:name="com.mw.MenuProvider" android:authorities="com.haibop.mobawar.mwmenu" android:exported="false"/>`
3. Mở `config.arm64_v8a.apk`, thêm `libmwmenu.so` vào `lib/arm64-v8a/`. Thêm ở chế độ KHÔNG nén (Store), vì file `.so` trong split thường không nén và cần căn chỉnh (zipalign).
4. Ký lại CẢ HAI APK bằng cùng một khóa, rồi cài bằng trình cài XAPK/split. Bản ký lại có thể phải gỡ bản cũ, nên sao lưu dữ liệu trước.

## 4. Dùng
- Vào một trận (solo/offline), bấm "Quét lại" nếu menu báo chưa thấy tướng.
- Tab "Chỉ số": liệt kê các trường số của `HeroDataComponent`, `HeroPassiveManager`, `SurvivalHeroBridge` (armor, flatBasicAttackBonus, damageMultiplier, buffLifestealPercent, totalCooldownReduction, totalLifestealPercent...). Nhập số rồi bấm OK.
- Công tắc "Lưu cài đặt": giữ giá trị đã sửa, tự áp lại mỗi 0,5 giây và khi mở lại game (lưu ở `files/mwmenu.txt`). Không đụng file save gốc.
- Tab "Tài nguyên": nhập số đang hiển thị (ví dụ 1552), bấm "Tìm", chọn một kết quả, nhập số lượng, bấm "Gửi" để CỘNG thêm vào mục đó.
- "Reset" đưa các chỉ số đã sửa về giá trị ban đầu. "Đóng" thu menu thành bong bóng "M" bên phải.

## 5. Lưu ý và rủi ro
- Chỉ dùng ở chế độ solo/offline. Mod không đụng đăng nhập, gift code, matchmaking.
- Game có `CheatingDetectionStatus`, theo dõi đỉnh tiền mỗi ngày (`maxCoinsToday`...) và đồng bộ cloud. Nên bật chế độ máy bay khi dùng "Tài nguyên" để giá trị đã sửa không bị đẩy lên cloud.
- Một số chỉ số game tự tính lại mỗi khung hình; bật "Lưu cài đặt" để áp lại liên tục.
- HP và hồi chiêu của tướng nằm trong `NetworkVariable` nên menu chưa sửa trực tiếp được. Phần này cần thêm hook phương thức, nên để lần sau.
- Nút "Gửi" ghi thẳng vào `PlayerData` rồi gọi `SavePlayerData(false)` từ luồng khác. Nếu game treo, đừng bấm "Gửi" nữa và báo mình.
