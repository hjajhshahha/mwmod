package com.mw;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Menu noi: panel keo tha + bong bong. Toan bo logic game nam trong libmwmenu.so (native). */
public final class Menu {
    static native boolean nInit(String dir);
    static native int nScan();
    static native String nStats();
    static native boolean nSetStat(String key, String value);
    static native void nReset();
    static native void nPersist(boolean on);
    static native boolean nGetPersist();
    static native void nTick();
    static native String nSearch(String num);
    static native String nGive(String id, String amount);

    private static Activity cur;
    private static Menu inst;
    private static boolean libOk;

    static synchronized void attach(Activity a) {
        if (!a.getClass().getName().startsWith("com.unity3d.player")) return;   // chi gan vao man hinh game
        if (inst != null && cur == a) return;
        if (!libOk) {
            try {
                System.loadLibrary("mwmenu");
                libOk = nInit(a.getFilesDir().getAbsolutePath());
            } catch (Throwable t) { libOk = false; }
        }
        cur = a;
        inst = new Menu(a);
    }

    static synchronized void detach(Activity a) {
        if (a == cur && inst != null) { inst.stop(); inst = null; cur = null; }
    }

    // ---------------- UI ----------------
    private final Activity act;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private final LinearLayout panel;
    private final TextView bubble;
    private final LinearLayout list;
    private final TextView status;
    private boolean statsTab = true;
    private volatile boolean running = true;
    private String giveId = null;
    private EditText giveAmt;
    private TextView giveLabel;
    private EditText searchBox;

    private int dp(int v) { return (int) (v * act.getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable bg(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private Button btn(String text) {
        Button b = new Button(act);
        b.setText(text); b.setTextSize(11); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackground(bg(0xFF3A4A6B, 6));
        b.setPadding(dp(8), 0, dp(8), 0); b.setMinHeight(0); b.setMinimumHeight(0);
        return b;
    }

    private TextView text(String s, int sp) {
        TextView t = new TextView(act);
        t.setText(s); t.setTextSize(sp); t.setTextColor(Color.WHITE);
        return t;
    }

    private Menu(Activity a) {
        act = a;
        // ---- panel ----
        panel = new LinearLayout(a);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(bg(0xE6101A2E, 10));
        panel.setPadding(dp(8), dp(6), dp(8), dp(6));

        TextView head = text("MW Mod  (keo de di chuyen)", 12);
        head.setTextColor(0xFFFFD54F);
        head.setPadding(0, 0, 0, dp(4));
        panel.addView(head);

        LinearLayout tabs = new LinearLayout(a);
        Button tStats = btn("Chi so"), tRes = btn("Tai nguyen"), tScan = btn("Quet lai");
        tabs.addView(tStats); tabs.addView(tRes); tabs.addView(tScan);
        panel.addView(tabs);

        status = text("", 10);
        status.setTextColor(0xFFB0BEC5);
        panel.addView(status);

        ScrollView sv = new ScrollView(a);
        list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        panel.addView(sv, new LinearLayout.LayoutParams(dp(290), dp(190)));

        LinearLayout foot = new LinearLayout(a);
        foot.setGravity(Gravity.CENTER_VERTICAL);
        CheckBox keep = new CheckBox(a);
        keep.setText("Luu cai dat"); keep.setTextSize(11); keep.setTextColor(Color.WHITE);
        keep.setChecked(libOk && nGetPersist());
        Button reset = btn("Reset"), close = btn("Dong");
        foot.addView(keep); foot.addView(reset); foot.addView(close);
        panel.addView(foot);

        // keo tha bang phan dau
        head.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) { dx = panel.getX() - e.getRawX(); dy = panel.getY() - e.getRawY(); }
                else if (e.getAction() == MotionEvent.ACTION_MOVE) { panel.setX(e.getRawX() + dx); panel.setY(e.getRawY() + dy); }
                return true;
            }
        });

        // ---- bubble ----
        bubble = text("M", 16);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(bg(0xCC3A4A6B, 28));
        bubble.setVisibility(View.GONE);

        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pp.leftMargin = dp(40); pp.topMargin = dp(20);
        a.addContentView(panel, pp);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END | Gravity.CENTER_VERTICAL);
        bp.rightMargin = dp(2);
        a.addContentView(bubble, bp);

        tStats.setOnClickListener(v -> { statsTab = true; refresh(); });
        tRes.setOnClickListener(v -> { statsTab = false; refresh(); });
        tScan.setOnClickListener(v -> rescan());
        keep.setOnCheckedChangeListener((b, on) -> { if (libOk) nPersist(on); });
        reset.setOnClickListener(v -> bg.execute(() -> { if (libOk) nReset(); ui.post(this::refresh); }));
        close.setOnClickListener(v -> { panel.setVisibility(View.GONE); bubble.setVisibility(View.VISIBLE); });
        bubble.setOnClickListener(v -> { bubble.setVisibility(View.GONE); panel.setVisibility(View.VISIBLE); refresh(); });

        // vong lap giu gia tri da luu
        bg.execute(new Runnable() {
            @Override public void run() {
                while (running) {
                    try { if (libOk) nTick(); Thread.sleep(500); } catch (Throwable t) { /* bo qua */ }
                }
            }
        });

        if (!libOk) status.setText("Khong nap duoc libmwmenu.so / libil2cpp.so");
        else rescan();
    }

    void stop() { running = false; bg.shutdownNow(); }

    private void rescan() {
        status.setText("Dang quet tuong (vao tran truoc)...");
        bg.execute(() -> {
            int n = libOk ? nScan() : -1;
            ui.post(() -> { status.setText(n > 0 ? "Tim thay " + n + " doi tuong" : "Chua thay tuong - vao tran roi bam Quet lai"); refresh(); });
        });
    }

    private void refresh() {
        if (statsTab) showStats(); else showRes();
    }

    // ---- tab chi so ----
    private void showStats() {
        list.removeAllViews();
        if (!libOk) return;
        bg.execute(() -> {
            final String data = nStats();
            ui.post(() -> {
                list.removeAllViews();
                if (data == null || data.isEmpty()) { list.addView(text("Chua co du lieu chi so", 11)); return; }
                for (String line : data.split("\n")) {
                    final String[] p = line.split("\\|");
                    if (p.length < 4) continue;
                    LinearLayout row = new LinearLayout(act);
                    row.setGravity(Gravity.CENTER_VERTICAL);
                    TextView name = text(p[1], 11);
                    final EditText val = new EditText(act);
                    val.setText(p[2]); val.setTextSize(11); val.setTextColor(0xFFFFEB3B);
                    val.setSingleLine(true); val.setPadding(dp(4), 0, dp(4), 0);
                    val.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED | (p[3].equals("f") ? InputType.TYPE_NUMBER_FLAG_DECIMAL : 0));
                    Button ok = btn("OK");
                    ok.setOnClickListener(v -> bg.execute(() -> nSetStat(p[0], val.getText().toString())));
                    row.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                    row.addView(val, new LinearLayout.LayoutParams(dp(80), ViewGroup.LayoutParams.WRAP_CONTENT));
                    row.addView(ok);
                    list.addView(row);
                }
            });
        });
    }

    // ---- tab tai nguyen ----
    private void showRes() {
        list.removeAllViews();
        LinearLayout bar = new LinearLayout(act);
        searchBox = new EditText(act);
        searchBox.setHint("nhap so can tim"); searchBox.setTextSize(11); searchBox.setTextColor(Color.WHITE);
        searchBox.setHintTextColor(0xFF90A4AE); searchBox.setSingleLine(true);
        searchBox.setInputType(InputType.TYPE_CLASS_NUMBER);
        Button go = btn("Tim");
        bar.addView(searchBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(go);
        list.addView(bar);

        LinearLayout giveBar = new LinearLayout(act);
        giveLabel = text("Chua chon muc nao", 10);
        giveAmt = new EditText(act);
        giveAmt.setHint("so luong"); giveAmt.setTextSize(11); giveAmt.setTextColor(0xFFFFEB3B);
        giveAmt.setHintTextColor(0xFF90A4AE); giveAmt.setSingleLine(true);
        giveAmt.setInputType(InputType.TYPE_CLASS_NUMBER);
        Button send = btn("Gui");
        giveBar.addView(giveLabel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        giveBar.addView(giveAmt, new LinearLayout.LayoutParams(dp(80), ViewGroup.LayoutParams.WRAP_CONTENT));
        giveBar.addView(send);
        list.addView(giveBar);

        final LinearLayout results = new LinearLayout(act);
        results.setOrientation(LinearLayout.VERTICAL);
        list.addView(results);

        go.setOnClickListener(v -> {
            final String q = searchBox.getText().toString().trim();
            if (q.isEmpty()) return;
            bg.execute(() -> {
                final String r = libOk ? nSearch(q) : "";
                ui.post(() -> {
                    results.removeAllViews();
                    if (r.startsWith("!")) { results.addView(text(r.substring(1), 11)); return; }
                    if (r.isEmpty()) { results.addView(text("Khong thay gia tri " + q, 11)); return; }
                    for (String line : r.split("\n")) {
                        final String[] p = line.split("\\|");
                        if (p.length < 4) continue;
                        TextView t = text(p[2] + " = " + p[3], 12);
                        t.setPadding(dp(4), dp(6), dp(4), dp(6));
                        t.setBackground(bg(0x33FFFFFF, 4));
                        t.setOnClickListener(x -> { giveId = p[0] + "|" + p[1]; giveLabel.setText("Chon: " + p[2]); });
                        results.addView(t);
                    }
                });
            });
        });
        send.setOnClickListener(v -> {
            if (giveId == null) { status.setText("Hay bam vao mot ket qua truoc"); return; }
            final String id = giveId, amt = giveAmt.getText().toString().trim();
            if (amt.isEmpty()) return;
            bg.execute(() -> {
                final String r = nGive(id, amt);
                ui.post(() -> status.setText(r));
            });
        });
    }
}
