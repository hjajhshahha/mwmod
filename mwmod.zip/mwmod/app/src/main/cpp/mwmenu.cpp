// MobaWar offline mod menu - native part (IL2CPP, arm64-v8a)
// Tra class/field theo TEN qua IL2CPP API nen khong phu thuoc offset co dinh.
#include <jni.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <string>
#include <vector>
#include <map>
#include <mutex>
#ifdef __ANDROID__
#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "MWMenu", __VA_ARGS__)
#else
#define LOGI(...) fprintf(stderr, __VA_ARGS__)
#endif

// ---------------- il2cpp function table ----------------
typedef void* (*f_domain_get)();
typedef void* (*f_thread_attach)(void*);
typedef void** (*f_domain_get_assemblies)(void*, size_t*);
typedef void* (*f_assembly_get_image)(void*);
typedef void* (*f_class_from_name)(void*, const char*, const char*);
typedef void* (*f_class_get_field_from_name)(void*, const char*);
typedef void* (*f_class_get_fields)(void*, void**);
typedef const char* (*f_field_get_name)(void*);
typedef size_t (*f_field_get_offset)(void*);
typedef void* (*f_field_get_type)(void*);
typedef int (*f_type_get_type)(void*);
typedef int (*f_field_get_flags)(void*);
typedef void (*f_field_static_get_value)(void*, void*);
typedef void* (*f_class_get_method_from_name)(void*, const char*, int);
typedef void* (*f_runtime_invoke)(void*, void*, void**, void**);
typedef void (*f_runtime_class_init)(void*);
typedef int (*f_string_length)(void*);
typedef uint16_t* (*f_string_chars)(void*);
typedef void* (*f_object_get_class)(void*);

static struct {
  f_domain_get domain_get; f_thread_attach thread_attach; f_domain_get_assemblies get_assemblies;
  f_assembly_get_image asm_image; f_class_from_name class_from_name;
  f_class_get_field_from_name field_from_name; f_class_get_fields class_fields;
  f_field_get_name field_name; f_field_get_offset field_offset; f_field_get_type field_type;
  f_type_get_type type_type; f_field_get_flags field_flags; f_field_static_get_value static_get;
  f_class_get_method_from_name method_from_name; f_runtime_invoke invoke;
  f_runtime_class_init class_init;
  f_string_length str_len; f_string_chars str_chars; f_object_get_class obj_class;
} I;

static bool g_ready = false;
static std::string g_dir;
static std::mutex g_mu;

template <class T> static bool sym(void* h, const char* n, T& out) {
  out = (T)dlsym(h, n);
  if (!out) LOGI("thieu symbol %s", n);
  return out != nullptr;
}

static bool loadApi() {
  void* h = dlopen("libil2cpp.so", RTLD_NOW | RTLD_NOLOAD);
  if (!h) h = dlopen("libil2cpp.so", RTLD_NOW);
  if (!h) return false;
  bool ok = true;
  ok &= sym(h, "il2cpp_domain_get", I.domain_get);
  ok &= sym(h, "il2cpp_thread_attach", I.thread_attach);
  ok &= sym(h, "il2cpp_domain_get_assemblies", I.get_assemblies);
  ok &= sym(h, "il2cpp_assembly_get_image", I.asm_image);
  ok &= sym(h, "il2cpp_class_from_name", I.class_from_name);
  ok &= sym(h, "il2cpp_class_get_field_from_name", I.field_from_name);
  ok &= sym(h, "il2cpp_class_get_fields", I.class_fields);
  ok &= sym(h, "il2cpp_field_get_name", I.field_name);
  ok &= sym(h, "il2cpp_field_get_offset", I.field_offset);
  ok &= sym(h, "il2cpp_field_get_type", I.field_type);
  ok &= sym(h, "il2cpp_type_get_type", I.type_type);
  ok &= sym(h, "il2cpp_field_get_flags", I.field_flags);
  ok &= sym(h, "il2cpp_field_static_get_value", I.static_get);
  ok &= sym(h, "il2cpp_class_get_method_from_name", I.method_from_name);
  ok &= sym(h, "il2cpp_runtime_invoke", I.invoke);
  ok &= sym(h, "il2cpp_runtime_class_init", I.class_init);
  ok &= sym(h, "il2cpp_string_length", I.str_len);
  ok &= sym(h, "il2cpp_string_chars", I.str_chars);
  ok &= sym(h, "il2cpp_object_get_class", I.obj_class);
  return ok;
}

static void attach() { if (I.domain_get && I.thread_attach) I.thread_attach(I.domain_get()); }

static void* findClass(const char* name) {
  size_t n = 0;
  void** asms = I.get_assemblies(I.domain_get(), &n);
  for (size_t i = 0; i < n; i++) {
    void* img = I.asm_image(asms[i]);
    void* k = img ? I.class_from_name(img, "", name) : nullptr;
    if (k) return k;
  }
  return nullptr;
}

// ---------------- field value helpers ----------------
enum { T_BOOL = 2, T_I1 = 4, T_U1 = 5, T_I2 = 6, T_U2 = 7, T_I4 = 8, T_U4 = 9, T_I8 = 10, T_U8 = 11, T_R4 = 12, T_R8 = 13 };
static bool isNumType(int t) { return t == T_BOOL || (t >= T_I1 && t <= T_R8); }

static double readNum(const void* p, int t) {
  switch (t) {
    case T_BOOL: case T_U1: return *(const uint8_t*)p;
    case T_I1: return *(const int8_t*)p;
    case T_I2: return *(const int16_t*)p;
    case T_U2: return *(const uint16_t*)p;
    case T_I4: return *(const int32_t*)p;
    case T_U4: return *(const uint32_t*)p;
    case T_I8: return (double)*(const int64_t*)p;
    case T_U8: return (double)*(const uint64_t*)p;
    case T_R4: return *(const float*)p;
    case T_R8: return *(const double*)p;
  }
  return 0;
}
static void writeNum(void* p, int t, double v) {
  switch (t) {
    case T_BOOL: *(uint8_t*)p = v != 0; break;
    case T_U1: *(uint8_t*)p = (uint8_t)v; break;
    case T_I1: *(int8_t*)p = (int8_t)v; break;
    case T_I2: *(int16_t*)p = (int16_t)v; break;
    case T_U2: *(uint16_t*)p = (uint16_t)v; break;
    case T_I4: *(int32_t*)p = v > 2147483647.0 ? 2147483647 : (v < -2147483648.0 ? INT32_MIN : (int32_t)v); break;
    case T_U4: *(uint32_t*)p = v < 0 ? 0 : (v > 4294967295.0 ? UINT32_MAX : (uint32_t)v); break;
    case T_I8: *(int64_t*)p = (int64_t)v; break;
    case T_U8: *(uint64_t*)p = v < 0 ? 0 : (uint64_t)v; break;
    case T_R4: *(float*)p = (float)v; break;
    case T_R8: *(double*)p = v; break;
  }
}
static std::string fmtNum(double v, int t) {
  char b[64];
  if (t == T_R4 || t == T_R8) snprintf(b, sizeof b, "%.4g", v);
  else snprintf(b, sizeof b, "%.0f", v);
  return b;
}
static std::string cleanName(const char* n) {  // "<armor>k__BackingField" -> "armor"
  std::string s = n;
  if (!s.empty() && s[0] == '<') { size_t e = s.find('>'); if (e != std::string::npos) return s.substr(1, e - 1); }
  return s;
}
static std::string utf8(void* str) {
  if (!str) return "";
  int n = I.str_len(str); uint16_t* c = I.str_chars(str);
  std::string o;
  for (int i = 0; i < n && i < 200; i++) {
    uint16_t u = c[i];
    if (u < 0x80) o += (char)u;
    else if (u < 0x800) { o += (char)(0xC0 | (u >> 6)); o += (char)(0x80 | (u & 63)); }
    else { o += (char)(0xE0 | (u >> 12)); o += (char)(0x80 | ((u >> 6) & 63)); o += (char)(0x80 | (u & 63)); }
  }
  return o;
}

// ---------------- heap scan (tim doi tuong theo con tro class) ----------------
// Doc /proc/self/mem bang pread nen vung nho bi go se tra ve loi, khong gay crash.
static std::vector<void*> scanInstances(void* klass) {
  std::vector<void*> out;
  int mem = open("/proc/self/mem", O_RDONLY);
  FILE* maps = fopen("/proc/self/maps", "r");
  if (mem < 0 || !maps) { if (mem >= 0) close(mem); if (maps) fclose(maps); return out; }
  char line[512];
  const size_t CH = 1 << 20;
  std::vector<uint8_t> buf(CH + 64);
  while (fgets(line, sizeof line, maps)) {
    unsigned long long a, b; char perm[8]; char path[400] = {0};
    int n = sscanf(line, "%llx-%llx %7s %*s %*s %*s %399[^\n]", &a, &b, perm, path);
    if (n < 3 || perm[0] != 'r' || perm[1] != 'w' || perm[3] != 'p') continue;
    const char* p = path; while (*p == ' ') p++;
    if (*p == '/' || strstr(p, "dalvik") || strstr(p, "stack") || strstr(p, "vvar") || strstr(p, "gralloc") || strstr(p, "ashmem") || strstr(p, "kgsl")) continue;
    if (b - a > (1ULL << 31)) continue;
    for (unsigned long long cur = a; cur < b; cur += CH) {
      size_t want = (size_t)((b - cur) > CH + 32 ? CH + 32 : (b - cur));
      ssize_t got = pread(mem, buf.data(), want, (off_t)cur);
      if (got < 24) continue;
      size_t lim = (size_t)got - 24; if (lim > CH) lim = CH;
      for (size_t o = 0; o <= lim; o += 8) {
        uint64_t w0 = *(uint64_t*)(buf.data() + o);
        if (w0 != (uint64_t)(uintptr_t)klass) continue;
        uint64_t w1 = *(uint64_t*)(buf.data() + o + 8);   // monitor
        uint64_t w2 = *(uint64_t*)(buf.data() + o + 16);  // m_CachedPtr (UnityEngine.Object)
        if (w1 == 0 && w2 != 0 && (w2 & 7) == 0) out.push_back((void*)(uintptr_t)(cur + o));
      }
    }
  }
  fclose(maps); close(mem);
  return out;
}

// ---------------- hero targets ----------------
struct Target { const char* cls; bool needNonBot; };
static const Target TARGETS[] = {
  {"HeroDataComponent", true}, {"HeroPassiveManager", false}, {"SurvivalHeroBridge", false},
};
static const int NT = sizeof(TARGETS) / sizeof(TARGETS[0]);

struct Inst { void* klass = nullptr; void* obj = nullptr; };
static Inst g_inst[8];
static std::map<std::string, double> g_saved;   // "Class.field" -> gia tri nguoi dung chon
static std::map<std::string, double> g_orig;    // gia tri goc truoc khi sua
static bool g_persist = false;
static long g_lastScanMs = 0;

static long nowMs() { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000L + ts.tv_nsec / 1000000L; }

static void* fieldOf(void* klass, const char* name) { return I.field_from_name(klass, name); }

static bool instAlive(const Inst& s) {
  if (!s.obj || !s.klass) return false;
  uint64_t* w = (uint64_t*)s.obj;
  return w[0] == (uint64_t)(uintptr_t)s.klass && w[2] != 0;   // m_CachedPtr = 0 -> doi tuong Unity da bi huy
}

static bool isRealHero(void* klass, void* obj) {
  void* fb = fieldOf(klass, "isBot");
  if (!fb) return true;
  uint8_t bot = *((uint8_t*)obj + I.field_offset(fb));
  return bot == 0;
}

static void rescan() {
  attach();
  for (int i = 0; i < NT; i++) {
    g_inst[i] = Inst();
    void* k = findClass(TARGETS[i].cls);
    if (!k) continue;
    g_inst[i].klass = k;
    std::vector<void*> v = scanInstances(k);
    for (void* o : v) {
      if (TARGETS[i].needNonBot && !isRealHero(k, o)) continue;
      g_inst[i].obj = o; break;
    }
  }
  g_lastScanMs = nowMs();
}

// Duyet cac truong so cua mot doi tuong da chon; fn(ten, kieu, con tro gia tri)
template <class F> static void forEachNumField(int i, F fn) {
  void* it = nullptr; void* f;
  while ((f = I.class_fields(g_inst[i].klass, &it)) != nullptr) {
    if (I.field_flags(f) & 0x50) continue;  // static / literal
    int t = I.type_type(I.field_type(f)); if (!isNumType(t)) continue;
    fn(cleanName(I.field_name(f)), t, (uint8_t*)g_inst[i].obj + I.field_offset(f));
  }
}

static void applySaved() {
  for (int i = 0; i < NT; i++) {
    if (!instAlive(g_inst[i])) continue;
    forEachNumField(i, [&](const std::string& nm, int t, void* p) {
      auto s = g_saved.find(std::string(TARGETS[i].cls) + "." + nm);
      if (s != g_saved.end() && readNum(p, t) != s->second) writeNum(p, t, s->second);
    });
  }
}

// ---------------- save/load file ----------------
static std::string cfgPath() { return g_dir + "/mwmenu.txt"; }
static void saveCfg() {
  FILE* f = fopen(cfgPath().c_str(), "w"); if (!f) return;
  fprintf(f, "persist=%d\n", g_persist ? 1 : 0);
  if (g_persist) for (auto& kv : g_saved) fprintf(f, "%s=%.9g\n", kv.first.c_str(), kv.second);
  fclose(f);
}
static void loadCfg() {
  FILE* f = fopen(cfgPath().c_str(), "r"); if (!f) return;
  char line[300];
  while (fgets(line, sizeof line, f)) {
    char* eq = strchr(line, '='); if (!eq) continue; *eq = 0;
    std::string k = line; double v = atof(eq + 1);
    if (k == "persist") g_persist = v != 0; else g_saved[k] = v;
  }
  fclose(f);
}

// ---------------- resources (PlayerData) ----------------
static void* playerData(void** pdmOut = nullptr) {
  void* k = findClass("PlayerDataManager"); if (!k) return nullptr;
  I.class_init(k);
  void* sf = fieldOf(k, "<Instance>k__BackingField"); if (!sf) return nullptr;
  void* inst = nullptr; I.static_get(sf, &inst); if (!inst) return nullptr;
  if (pdmOut) *pdmOut = inst;
  void* pf = fieldOf(k, "playerData"); if (!pf) return nullptr;
  return *(void**)((uint8_t*)inst + I.field_offset(pf));
}
static const char* resLabel(const std::string& f) {
  if (f == "currency") return "Vang";
  if (f == "diamonds") return "Kim cuong";
  if (f == "universalShards") return "Manh van nang";
  if (f == "stamina") return "The luc";
  if (f == "accountExp") return "Kinh nghiem";
  if (f == "accountLevel") return "Cap tai khoan";
  return "";
}
static const char* RES_FIELDS[] = {"currency", "diamonds", "universalShards", "stamina", "accountExp", "accountLevel"};

// List<T> -> (mang phan tu, so luong)
static bool listItems(void* list, void*** arr, int* size) {
  if (!list) return false;
  void* lk = I.obj_class(list);
  void* fi = fieldOf(lk, "_items"); void* fs = fieldOf(lk, "_size");
  if (!fi || !fs) return false;
  void* a = *(void**)((uint8_t*)list + I.field_offset(fi));
  *size = *(int*)((uint8_t*)list + I.field_offset(fs));
  if (!a || *size <= 0) { *size = 0; return false; }
  *arr = (void**)((uint8_t*)a + 0x20);   // Il2CppArray: header(16) + bounds(8) + max_length(8) -> du lieu
  return true;
}

// ---------------- JNI ----------------
static jstring jstr(JNIEnv* e, const std::string& s) { return e->NewStringUTF(s.c_str()); }
static std::string cstr(JNIEnv* e, jstring s) {
  const char* c = e->GetStringUTFChars(s, nullptr); std::string r = c ? c : "";
  if (c) e->ReleaseStringUTFChars(s, c);
  return r;
}

extern "C" {

JNIEXPORT jboolean JNICALL Java_com_mw_Menu_nInit(JNIEnv* e, jclass, jstring dir) {
  g_dir = cstr(e, dir);
  g_ready = loadApi();
  if (g_ready) loadCfg();
  return g_ready;
}

JNIEXPORT jint JNICALL Java_com_mw_Menu_nScan(JNIEnv*, jclass) {
  if (!g_ready) return -1;
  std::lock_guard<std::mutex> lk(g_mu);
  rescan();
  int c = 0; for (int i = 0; i < NT; i++) if (instAlive(g_inst[i])) c++;
  return c;
}

// moi dong: "Class.field|ten hien thi|gia tri|loai(f/i/b)"
JNIEXPORT jstring JNICALL Java_com_mw_Menu_nStats(JNIEnv* e, jclass) {
  std::string out;
  if (!g_ready) return jstr(e, out);
  std::lock_guard<std::mutex> lk(g_mu);
  attach();
  for (int i = 0; i < NT; i++) {
    if (!instAlive(g_inst[i])) continue;
    forEachNumField(i, [&](const std::string& nm, int t, void* p) {
      out += std::string(TARGETS[i].cls) + "." + nm + "|" + nm + "|" + fmtNum(readNum(p, t), t) + "|" +
             (t == T_R4 || t == T_R8 ? "f" : (t == T_BOOL ? "b" : "i")) + "\n";
    });
  }
  return jstr(e, out);
}

JNIEXPORT jboolean JNICALL Java_com_mw_Menu_nSetStat(JNIEnv* e, jclass, jstring jkey, jstring jval) {
  if (!g_ready) return false;
  std::string key = cstr(e, jkey), val = cstr(e, jval);
  size_t dot = key.find('.'); if (dot == std::string::npos) return false;
  std::string cls = key.substr(0, dot), fld = key.substr(dot + 1);
  std::lock_guard<std::mutex> lk(g_mu);
  attach();
  bool done = false;
  for (int i = 0; i < NT && !done; i++) {
    if (cls != TARGETS[i].cls || !instAlive(g_inst[i])) continue;
    forEachNumField(i, [&](const std::string& nm, int t, void* p) {
      if (done || nm != fld) return;
      double v = atof(val.c_str());
      if (!g_orig.count(key)) g_orig[key] = readNum(p, t);
      writeNum(p, t, v);
      g_saved[key] = readNum(p, t);
      done = true;
    });
  }
  if (done) saveCfg();
  return done;
}

JNIEXPORT void JNICALL Java_com_mw_Menu_nReset(JNIEnv*, jclass) {
  if (!g_ready) return;
  std::lock_guard<std::mutex> lk(g_mu);
  attach();
  for (auto& kv : g_orig) {
    size_t dot = kv.first.find('.');
    std::string cls = kv.first.substr(0, dot), fld = kv.first.substr(dot + 1);
    for (int i = 0; i < NT; i++) {
      if (cls != TARGETS[i].cls || !instAlive(g_inst[i])) continue;
      forEachNumField(i, [&](const std::string& nm, int t, void* p) {
        if (nm == fld) writeNum(p, t, kv.second);
      });
    }
  }
  g_orig.clear(); g_saved.clear();
  saveCfg();
}

JNIEXPORT void JNICALL Java_com_mw_Menu_nPersist(JNIEnv*, jclass, jboolean on) {
  g_persist = on; saveCfg();
}
JNIEXPORT jboolean JNICALL Java_com_mw_Menu_nGetPersist(JNIEnv*, jclass) { return g_persist; }

// Goi dinh ky: giu gia tri da luu, tu quet lai khi tuong bi huy (doi man/tran moi)
JNIEXPORT void JNICALL Java_com_mw_Menu_nTick(JNIEnv*, jclass) {
  if (!g_ready || !g_persist || g_saved.empty()) return;
  std::unique_lock<std::mutex> lk(g_mu, std::try_to_lock);
  if (!lk.owns_lock()) return;
  attach();
  bool dead = !instAlive(g_inst[0]);
  if (dead && nowMs() - g_lastScanMs > 4000) rescan();
  applySaved();
}

// tim gia tri tai nguyen: moi dong "id|nhan|gia tri"
JNIEXPORT jstring JNICALL Java_com_mw_Menu_nSearch(JNIEnv* e, jclass, jstring jnum) {
  std::string out;
  if (!g_ready) return jstr(e, out);
  double want = atof(cstr(e, jnum).c_str());
  std::lock_guard<std::mutex> lk(g_mu);
  attach();
  void* pd = playerData();
  if (!pd) return jstr(e, "!Chua vao game (chua co du lieu nguoi choi)");
  void* pk = I.obj_class(pd);
  char buf[200];
  for (const char* fn : RES_FIELDS) {
    void* f = fieldOf(pk, fn); if (!f) continue;
    int t = I.type_type(I.field_type(f)); if (!isNumType(t)) continue;
    double v = readNum((uint8_t*)pd + I.field_offset(f), t);
    if (v == want) { snprintf(buf, sizeof buf, "f|%s|%s (%s)|%s\n", fn, resLabel(fn), fn, fmtNum(v, t).c_str()); out += buf; }
  }
  struct L { const char* field; const char* idf; const char* cntf; const char* tag; const char* lab; };
  const L lists[] = {{"heroShards", "heroID", "shardCount", "h", "Manh tuong"}, {"ownedItems", "itemID", "quantity", "i", "Vat pham"}};
  for (const L& l : lists) {
    void* lf = fieldOf(pk, l.field); if (!lf) continue;
    void* list = *(void**)((uint8_t*)pd + I.field_offset(lf));
    void** arr = nullptr; int n = 0;
    if (!listItems(list, &arr, &n)) continue;
    for (int i = 0; i < n; i++) {
      void* el = arr[i]; if (!el) continue;
      void* ek = I.obj_class(el);
      void* cf = fieldOf(ek, l.cntf); void* idf = fieldOf(ek, l.idf); if (!cf) continue;
      int t = I.type_type(I.field_type(cf));
      double v = readNum((uint8_t*)el + I.field_offset(cf), t);
      if (v != want) continue;
      std::string id = idf ? utf8(*(void**)((uint8_t*)el + I.field_offset(idf))) : "?";
      snprintf(buf, sizeof buf, "%s|%d|%s: %s|%s\n", l.tag, i, l.lab, id.c_str(), fmtNum(v, t).c_str());
      out += buf;
    }
  }
  return jstr(e, out);
}

// cong them 'amount' vao muc da chon (id lay tu nSearch: "f|ten" / "h|chi so" / "i|chi so")
JNIEXPORT jstring JNICALL Java_com_mw_Menu_nGive(JNIEnv* e, jclass, jstring jid, jstring jamt) {
  if (!g_ready) return jstr(e, "Chua san sang");
  std::string id = cstr(e, jid); double amt = atof(cstr(e, jamt).c_str());
  std::lock_guard<std::mutex> lk(g_mu);
  attach();
  void* pdm = nullptr; void* pd = playerData(&pdm);
  if (!pd) return jstr(e, "Chua vao game");
  void* pk = I.obj_class(pd);
  std::string tag = id.substr(0, 1), rest = id.size() > 2 ? id.substr(2) : "";
  void* target = nullptr; int t = 0;
  if (tag == "f") {
    void* f = fieldOf(pk, rest.c_str()); if (!f) return jstr(e, "Khong thay truong");
    t = I.type_type(I.field_type(f)); target = (uint8_t*)pd + I.field_offset(f);
  } else {
    const char* lname = tag == "h" ? "heroShards" : "ownedItems";
    const char* cname = tag == "h" ? "shardCount" : "quantity";
    void* lf = fieldOf(pk, lname); if (!lf) return jstr(e, "Khong thay danh sach");
    void** arr = nullptr; int n = 0;
    if (!listItems(*(void**)((uint8_t*)pd + I.field_offset(lf)), &arr, &n)) return jstr(e, "Danh sach rong");
    int idx = atoi(rest.c_str());
    if (idx < 0 || idx >= n || !arr[idx]) return jstr(e, "Muc da thay doi, hay tim lai");
    void* cf = fieldOf(I.obj_class(arr[idx]), cname); if (!cf) return jstr(e, "Khong thay truong so luong");
    t = I.type_type(I.field_type(cf)); target = (uint8_t*)arr[idx] + I.field_offset(cf);
  }
  double cur = readNum(target, t);
  writeNum(target, t, cur + amt);
  double now = readNum(target, t);
  // Luu qua ham cua game (khong ep dong bo cloud). Neu loi thi bo qua, game tu luu khi thoat.
  void* m = I.method_from_name(I.obj_class(pdm), "SavePlayerData", 1);
  if (m) { uint8_t force = 0; void* args[1] = {&force}; void* exc = nullptr; I.invoke(m, pdm, args, &exc); }
  return jstr(e, "OK: " + fmtNum(cur, t) + " -> " + fmtNum(now, t));
}

}  // extern "C"
